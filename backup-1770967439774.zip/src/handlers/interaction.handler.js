const {
  serverSelect,
  vipSelect,
  buyButton
} = require("../ui/components");

const {
  createOrder,
  updateOrder,
  createCheckout,
  getOrderBySteam
} = require("../services/backend.service");

const userState = new Map();

async function handleInteraction(interaction) {
  try {
    /* ===============================
       BOTÃO: CONECTAR STEAM
    =============================== */
    if (interaction.isButton() && interaction.customId === "connect_steam") {
      await interaction.deferReply({ ephemeral: true });

      const order = await createOrder({
        discordId: interaction.user.id
      });

      userState.set(interaction.user.id, {
        order_nsu: order.order_nsu
      });

      return interaction.editReply({
        content:
          `🔗 **Passo 1: Conectar Steam**\n\n` +
          `${order.steamLoginUrl}\n\n` +
          `Após conectar, clique em **Já conectei minha Steam**.`
      });
    }

    /* ===============================
       BOTÃO: JÁ CONECTEI STEAM
    =============================== */
    if (interaction.isButton() && interaction.customId === "steam_done") {
      await interaction.deferReply({ ephemeral: true });

      const order = await getOrderBySteam(interaction.user.id);

      userState.set(interaction.user.id, {
        order_nsu: order.order_nsu
      });

      return interaction.editReply({
        content: "✅ Steam conectada! Agora escolha o servidor e o VIP.",
        components: [serverSelect(), vipSelect(), buyButton()]
      });
    }

    /* ===============================
       SELECT: SERVIDOR
    =============================== */
    if (interaction.isStringSelectMenu() && interaction.customId === "select_server") {
      const state = userState.get(interaction.user.id);
      state.serverId = interaction.values[0];
      userState.set(interaction.user.id, state);

      return interaction.reply({ content: "Servidor selecionado.", ephemeral: true });
    }

    /* ===============================
       SELECT: VIP
    =============================== */
    if (interaction.isStringSelectMenu() && interaction.customId === "select_vip") {
      const state = userState.get(interaction.user.id);
      state.vipType = interaction.values[0];
      userState.set(interaction.user.id, state);

      return interaction.reply({ content: "VIP selecionado.", ephemeral: true });
    }

    /* ===============================
       BOTÃO: COMPRAR
    =============================== */
    if (interaction.isButton() && interaction.customId === "buy_vip") {
      const state = userState.get(interaction.user.id);

      await interaction.deferReply({ ephemeral: true });

      await updateOrder(state.order_nsu, {
        serverId: state.serverId,
        vipType: state.vipType
      });

      const checkoutUrl = await createCheckout(state.order_nsu);

      return interaction.editReply({
        content:
          `💳 **Pagamento**\n\n${checkoutUrl}\n\n` +
          `Após o pagamento, o VIP será ativado automaticamente.`
      });
    }
  } catch (err) {
    console.error(err);

    if (interaction.deferred) {
      return interaction.editReply("❌ Ocorreu um erro.");
    }

    return interaction.reply({ content: "❌ Ocorreu um erro.", ephemeral: true });
  }
}

module.exports = { handleInteraction };