const axios = require("axios");
const { backendUrl, botTokenSecret } = require("../config/env");

const api = axios.create({
  baseURL: backendUrl,
  headers: {
    "Content-Type": "application/json",
    "x-bot-token": botTokenSecret
  }
});

async function createOrder(data) {
  const res = await api.post("/orders", data);
  return res.data;
}

async function updateOrder(orderNsu, data) {
  const res = await api.patch(`/orders/${orderNsu}`, data);
  return res.data;
}

async function createCheckout(orderNsu) {
  const res = await api.post("/orders/checkout", { order_nsu: orderNsu });
  return res.data.checkoutUrl;
}

async function getOrderBySteam(steamId64) {
  const res = await api.get(`/orders/by-steam/${steamId64}`);
  return res.data;
}

module.exports = {
  createOrder,
  updateOrder,
  createCheckout,
  getOrderBySteam
};