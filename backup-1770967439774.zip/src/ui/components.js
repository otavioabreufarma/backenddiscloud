const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder
} = require("discord.js");

/**
 * 🔗 Botão conectar Steam
 */
function connectSteamButton() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("connect_steam")
      .setLabel("🔗 Conectar Steam")
      .setStyle(ButtonStyle.Primary)
  );
}

/**
 * ✅ Botão confirmar que já conectou a Steam
 */
function steamDoneButton() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("steam_done")
      .setLabel("✅ Já conectei minha Steam")
      .setStyle(ButtonStyle.Success)
  );
}

/**
 * 🖥️ Select de servidores
 */
function serverSelect() {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("select_server")
      .setPlaceholder("Selecione o servidor")
      .addOptions([
        {
          label: "Servidor 1",
          value: "server1"
        },
        {
          label: "Servidor 2",
          value: "server2"
        }
      ])
  );
}

/**
 * 💎 Select de VIP
 */
function vipSelect() {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("select_vip")
      .setPlaceholder("Selecione o VIP")
      .addOptions([
        {
          label: "VIP - R$15",
          value: "vip"
        },
        {
          label: "VIP+ - R$30",
          value: "vip+"
        }
      ])
  );
}

/**
 * 💳 Botão comprar VIP
 */
function buyButton() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("buy_vip")
      .setLabel("💳 Comprar VIP")
      .setStyle(ButtonStyle.Success)
  );
}

module.exports = {
  connectSteamButton,
  steamDoneButton,
  serverSelect,
  vipSelect,
  buyButton
};