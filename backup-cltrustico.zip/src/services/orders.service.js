const { v4: uuid } = require("uuid");
const { JsonDb } = require("../utils/jsonDb");

const ordersDb = new JsonDb("orders.json");
const serversDb = new JsonDb("servers.json");

/**
 * Preços oficiais
 */
const VIP_PRICES = {
  vip: 15,
  "vip+": 30
};

/**
 * =====================================================
 * 🟢 CRIA ORDER APÓS LOGIN STEAM (FLUXO CORRETO)
 * =====================================================
 */
async function createOrderWithSteam({ steamId64 }) {
  if (!steamId64) {
    throw new Error("steamId64 is required");
  }

  const orders = await ordersDb.read();

  // Evita múltiplas orders pendentes para a mesma Steam
  const existing = orders.find(
    o => o.steamId64 === steamId64 && o.status === "PENDING"
  );
  if (existing) {
    return existing;
  }

  const order = {
    order_nsu: `INF-${uuid().slice(0, 8)}`,
    discordId: null,
    steamId64,
    serverId: null,
    vipType: null,
    price: null,
    status: "PENDING",
    checkoutUrl: null,
    createdAt: new Date().toISOString(),
    paidAt: null
  };

  orders.push(order);
  await ordersDb.write(orders);

  return order;
}

/**
 * =====================================================
 * 🟡 VINCULA DISCORD À ORDER (APÓS STEAM)
 * =====================================================
 */
async function attachDiscordToOrder({ order_nsu, discordId }) {
  if (!order_nsu || !discordId) {
    throw new Error("order_nsu and discordId are required");
  }

  const orders = await ordersDb.read();
  const order = orders.find(o => o.order_nsu === order_nsu);

  if (!order) {
    throw new Error("Order not found");
  }

  order.discordId = discordId;
  await ordersDb.write(orders);

  return order;
}

/**
 * =====================================================
 * 🖥️ ATUALIZA SERVER + VIP
 * =====================================================
 */
async function updateOrder(order_nsu, { serverId, vipType }) {
  if (!order_nsu) {
    throw new Error("order_nsu is required");
  }

  await validateServerAndVip(serverId, vipType);

  const orders = await ordersDb.read();
  const order = orders.find(o => o.order_nsu === order_nsu);

  if (!order) {
    throw new Error("Order not found");
  }

  if (order.status !== "PENDING") {
    throw new Error("Order cannot be modified");
  }

  order.serverId = serverId;
  order.vipType = vipType;
  order.price = VIP_PRICES[vipType];

  await ordersDb.write(orders);
  return order;
}

/**
 * =====================================================
 * 🔍 BUSCAR ORDER POR NSU
 * =====================================================
 */
async function getOrderByNsu(order_nsu) {
  const orders = await ordersDb.read();
  return orders.find(o => o.order_nsu === order_nsu) || null;
}

/**
 * =====================================================
 * 🔍 BUSCAR ORDER ATIVA POR STEAM
 * =====================================================
 */
async function getPendingOrderBySteam(steamId64) {
  const orders = await ordersDb.read();
  return (
    orders.find(
      o => o.steamId64 === steamId64 && o.status === "PENDING"
    ) || null
  );
}

/**
 * =====================================================
 * 🔐 VALIDA SERVER E VIP
 * =====================================================
 */
async function validateServerAndVip(serverId, vipType) {
  if (!serverId || !vipType) {
    throw new Error("serverId and vipType are required");
  }

  if (!VIP_PRICES[vipType]) {
    throw new Error("Invalid vipType");
  }

  const servers = await serversDb.read();
  const exists = servers.some(s => s.id === serverId);

  if (!exists) {
    throw new Error("Invalid serverId");
  }
}

module.exports = {
  createOrderWithSteam,
  attachDiscordToOrder,
  updateOrder,
  getOrderByNsu,
  getPendingOrderBySteam
};