const path = require("path");
const jsonfile = require("jsonfile");

const vipFile = path.join(__dirname, "../storage/vips.json");

async function readVips() {
  try {
    return await jsonfile.readFile(vipFile);
  } catch {
    return [];
  }
}

async function getVipBySteamId(steamId64) {
  const vips = await readVips();
  return vips.find(v => v.steamId64 === steamId64 && v.active);
}

module.exports = {
  getVipBySteamId
};