const {
  createOrder,
  getOrderByNsu,
  getPendingOrderBySteam,
  updateOrder
} = require("../services/orders.service");

/**
 * POST /orders
 * Cria uma order inicial (antes do login Steam)
 */
async function createOrderController(req, res, next) {
  try {
    const { discordId } = req.body;

    if (!discordId) {
      return res.status(400).json({ error: "discordId is required" });
    }

    const order = await createOrder({ discordId });
    res.status(201).json(order);
  } catch (err) {
    next(err);
  }
}

/**
 * GET /orders/:order_nsu
 * Retorna uma order específica
 */
async function getOrderController(req, res, next) {
  try {
    const { order_nsu } = req.params;

    const order = await getOrderByNsu(order_nsu);

    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }

    res.json(order);
  } catch (err) {
    next(err);
  }
}

/**
 * GET /orders/by-steam/:steamId64
 * Retorna order pendente vinculada a uma Steam
 */
async function getOrderBySteamController(req, res, next) {
  try {
    const { steamId64 } = req.params;

    if (!steamId64) {
      return res.status(400).json({ error: "steamId64 is required" });
    }

    const order = await getPendingOrderBySteam(steamId64);

    if (!order) {
      return res.status(404).json({ error: "No pending order found" });
    }

    res.json(order);
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /orders/:order_nsu
 * Atualiza servidor e tipo de VIP
 */
async function updateOrderController(req, res, next) {
  try {
    const { order_nsu } = req.params;
    const { serverId, vipType } = req.body;

    if (!serverId || !vipType) {
      return res
        .status(400)
        .json({ error: "serverId and vipType are required" });
    }

    const updated = await updateOrder(order_nsu, {
      serverId,
      vipType
    });

    res.json(updated);
  } catch (err) {
    next(err);
  }
}

module.exports = {
  createOrderController,
  getOrderController,
  getOrderBySteamController,
  updateOrderController
};