const { Router } = require("express");
const passport = require("passport");
const { createOrderWithSteam } = require("../services/orders.service");

const router = Router();

/**
 * Login Steam (SEM order)
 */
router.get("/login", passport.authenticate("steam"));

/**
 * Callback Steam
 * Aqui a order é criada
 */
router.get(
  "/callback",
  passport.authenticate("steam", { failureRedirect: "/" }),
  async (req, res, next) => {
    try {
      const steamId64 = req.user.steamId64;

      // Cria order vinculada à Steam
      const order = await createOrderWithSteam({
        steamId64
      });

      res.send(
        `Steam conectada com sucesso. Volte ao Discord.\n\nORDER:${order.order_nsu}`
      );
    } catch (err) {
      next(err);
    }
  }
);

module.exports = router;