const { Router } = require("express");
const { botAuth } = require("../middlewares/auth.middleware");

const {
  getOrderBySteamController,
  getOrderController,
  updateOrderController
} = require("../controllers/orders.controller");

const { createCheckoutController } = require("../controllers/checkout.controller");

const router = Router();

/**
 * ⚠️ SEMPRE ANTES DE /:order_nsu
 * GET /orders/by-steam/:steamId64
 */
router.get("/by-steam/:steamId64", botAuth, getOrderBySteamController);

/**
 * GET /orders/:order_nsu
 */
router.get("/:order_nsu", botAuth, getOrderController);

/**
 * PATCH /orders/:order_nsu
 */
router.patch("/:order_nsu", botAuth, updateOrderController);

/**
 * POST /orders/checkout/:order_nsu
 */
router.post("/checkout/:order_nsu", botAuth, createCheckoutController);

module.exports = router;