const { v4: uuid } = require("uuid");
const { JsonDb } = require("../utils/jsonDb");

const ordersDb = new JsonDb("orders.json");
const serversDb = new JsonDb("servers.json");

const VIP_PRICES = { vip: 15, "vip+": 30 };

async function createOrder({ discordId, serverId, vipType }) {
  if (!VIP_PRICES[vipType]) throw new Error("Invalid VIP");

  const servers = await serversDb.read();
  if (!servers.find(s => s.id === serverId)) throw new Error("Invalid server");

  const orders = await ordersDb.read();
  const existing = orders.find(
    o =>
      o.discordId === discordId &&
      o.serverId === serverId &&
      o.vipType === vipType &&
      o.status === "PENDING"
  );

  if (existing) return existing;

  const order = {
    order_nsu: `INF-${uuid().slice(0, 8)}`,
    discordId,
    steamId64: null,
    serverId,
    vipType,
    price: VIP_PRICES[vipType],
    status: "PENDING",
    checkoutUrl: null,
    createdAt: new Date().toISOString(),
    paidAt: null
  };

  orders.push(order);
  await ordersDb.write(orders);
  return order;
}

module.exports = { createOrder };