const axios = require("axios");
const { JsonDb } = require("../utils/jsonDb");
const { rustToken, rustPluginUrl } = require("../config/env");

const ordersDb = new JsonDb("orders.json");
const vipsDb = new JsonDb("vips.json");

async function activateVip(order_nsu) {
  const orders = await ordersDb.read();
  const order = orders.find(o => o.order_nsu === order_nsu);
  if (order.status !== "PAID") throw new Error("Not paid");

  const vips = await vipsDb.read();
  if (vips.find(v => v.order_nsu === order_nsu)) return;

  await axios.post(
    `${rustPluginUrl}/vip/apply`,
    { steamId64: order.steamId64, serverId: order.serverId, vipType: order.vipType },
    { headers: { "x-rust-token": rustToken } }
  );

  vips.push({
    steamId64: order.steamId64,
    discordId: order.discordId,
    serverId: order.serverId,
    vipType: order.vipType,
    order_nsu,
    startsAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 30 * 86400000).toISOString(),
    active: true
  });

  await vipsDb.write(vips);
}

module.exports = { activateVip };