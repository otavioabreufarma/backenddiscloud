const { Router } = require("express");
const passport = require("passport");
const { attachSteamToOrder } = require("../services/steam.service");

const router = Router();

router.get("/login", (req, res, next) => {
  req.session.order_nsu = req.query.order_nsu;
  next();
}, passport.authenticate("steam"));

router.get("/callback",
  passport.authenticate("steam", { failureRedirect: "/" }),
  async (req, res) => {
    await attachSteamToOrder(req.session.order_nsu, req.user.steamId64);
    res.send("Steam conectado. Volte ao Discord.");
  }
);

module.exports = router;