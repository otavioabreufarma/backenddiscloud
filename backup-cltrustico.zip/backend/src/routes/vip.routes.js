const { Router } = require("express");
const { rustAuth } = require("../middlewares/auth.middleware");
const { JsonDb } = require("../utils/jsonDb");

const router = Router();
const vipsDb = new JsonDb("vips.json");

router.get("/status", rustAuth, async (req, res) => {
  const { steamId64, serverId } = req.query;
  const vips = await vipsDb.read();
  const vip = vips.find(v => v.active && v.steamId64 === steamId64 && v.serverId === serverId);
  res.json(vip ? { active: true, expiresAt: vip.expiresAt } : { active: false });
});

module.exports = router;