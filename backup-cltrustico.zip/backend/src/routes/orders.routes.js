const { Router } = require("express");
const { botAuth } = require("../middlewares/auth.middleware");
const { createOrderController } = require("../controllers/orders.controller");
const { createCheckoutController } = require("../controllers/checkout.controller");

const router = Router();

router.post("/", botAuth, createOrderController);
router.post("/checkout", botAuth, createCheckoutController);

module.exports = router;