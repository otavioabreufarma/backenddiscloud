const { Router } = require("express");

const orders = require("./orders.routes");
const steam = require("./steam.routes");
const webhooks = require("./webhook.routes");
const vip = require("./vip.routes");

const router = Router();

router.use("/orders", orders);
router.use("/auth/steam", steam);
router.use("/webhooks", webhooks);
router.use("/vip", vip);

module.exports = router;