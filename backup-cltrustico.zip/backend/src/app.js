const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const session = require("express-session");
const passport = require("./config/steam");

const routes = require("./routes");
const { errorMiddleware } = require("./middlewares/error.middleware");
const { rateLimitMiddleware } = require("./middlewares/rateLimit.middleware");

const app = express();

/**
 * 🔴 OBRIGATÓRIO PARA CLOUDFARE / DISCLOUD
 * Permite que Express confie no X-Forwarded-For
 * Evita erro 502 com express-rate-limit
 */
app.set("trust proxy", 1);

// Segurança básica
app.use(helmet());

// CORS (ajuste se quiser restringir domínio)
app.use(cors());

// JSON body
app.use(express.json());

// Rate limit (agora funciona corretamente)
app.use(rateLimitMiddleware);

// Sessão necessária para Steam OpenID
app.use(
  session({
    name: "steam.sid",
    secret: process.env.SESSION_SECRET || "steam-session-dev",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Discloud termina SSL no proxy
      httpOnly: true,
      sameSite: "lax"
    }
  })
);

// Passport (Steam)
app.use(passport.initialize());
app.use(passport.session());

// Rotas da API
app.use("/api", routes);

// Middleware de erro (SEMPRE POR ÚLTIMO)
app.use(errorMiddleware);

module.exports = app;