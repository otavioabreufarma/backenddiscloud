const { generateCheckout } = require("../services/infinitepay.service");

async function createCheckoutController(req, res, next) {
  try {
    const { order_nsu } = req.body;
    const checkoutUrl = await generateCheckout(order_nsu);
    res.json({ checkoutUrl });
  } catch (e) {
    next(e);
  }
}

module.exports = { createCheckoutController };