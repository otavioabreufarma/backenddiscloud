const { createOrder } = require("../services/orders.service");

async function createOrderController(req, res, next) {
  try {
    const { discordId, serverId, vipType } = req.body;
    const order = await createOrder({ discordId, serverId, vipType });
    res.json({ order_nsu: order.order_nsu });
  } catch (e) {
    next(e);
  }
}

module.exports = { createOrderController };