const rateLimit = require("express-rate-limit");

module.exports.rateLimitMiddleware = rateLimit({
  windowMs: 60 * 1000,
  max: 100,

  /**
   * 🔴 OBRIGATÓRIO EM CLOUDFARE / PROXY
   * Desativa a validação que está quebrando o backend
   */
  validate: {
    xForwardedForHeader: false
  },

  standardHeaders: true,
  legacyHeaders: false
});