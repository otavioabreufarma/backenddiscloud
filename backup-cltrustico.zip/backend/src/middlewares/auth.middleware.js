const { botToken, rustToken } = require("../config/env");

function botAuth(req, res, next) {
  if (req.headers["x-bot-token"] !== botToken) {
    return res.status(401).json({ error: "Invalid bot token" });
  }
  next();
}

function rustAuth(req, res, next) {
  if (req.headers["x-rust-token"] !== rustToken) {
    return res.status(401).json({ error: "Invalid rust token" });
  }
  next();
}

module.exports = { botAuth, rustAuth };